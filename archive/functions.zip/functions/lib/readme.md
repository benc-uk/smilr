# Note
The **data-access.js** & **utils.js** files here are an exact copies of the files found in the **node/data-api** sub-project