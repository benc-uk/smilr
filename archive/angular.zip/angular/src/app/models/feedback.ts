
// Basic model to hold some feedback

export class Feedback {
  id: number;
  event: string;
  topic: number;
  rating: number;
  comment: string;
}