# Angular SPA Client

### :warning: NOTE!
This sub project now is deprecated, and has been replace with the [newer Vue.js client app](../vue)
